(() => {
  const rows = document.getElementById('record-rows');
  if (rows) {
    const fragment = document.createDocumentFragment();
    for (let i = 1; i <= 15; i++) {
      const tr = document.createElement('tr');
      const values = [String(i).padStart(2, '0'), 'Not provided', 'Not provided', 'Not provided', 'Not provided'];
      values.forEach((value, index) => {
        const cell = document.createElement('td');
        if (index === 0) cell.textContent = value;
        else cell.textContent = value;
        tr.appendChild(cell);
      });
      fragment.appendChild(tr);
    }
    rows.appendChild(fragment);
  }
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.getElementById('primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open navigation');
    }));
  }
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
})();
