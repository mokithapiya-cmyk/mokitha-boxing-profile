# Mokitha Piyarathna — Athlete Profile

A standalone, responsive static website built with HTML, CSS and vanilla JavaScript. No framework, paid build tool, or third-party builder branding is required. The six supplied photos are included as locally hosted WebP assets in `assets/`.

## Preview locally

Open `index.html` in a browser. For a local web-server preview, run `python3 -m http.server 8000` from this folder, then visit `http://localhost:8000`.

## Deploy free with Cloudflare Pages

1. Create a GitHub account if you do not already have one, create a new repository (for example `mokitha-athlete-profile`), and upload the **contents** of this folder including `assets/`.
2. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git** and select that repository.
3. Choose **None** / static HTML as the framework preset. Leave build command blank and set build output directory to `/` (or the repository root, depending on the current dashboard wording).
4. Deploy. Cloudflare will provide a temporary `*.pages.dev` URL. This is only a preview/hosting URL; use a custom domain below for the permanent public address.
5. Check the deployed homepage and each image in the gallery before announcing the site.

Cloudflare Pages static hosting has a free tier; plan terms can change. No purchase is required to deploy on the temporary Pages URL.

## Custom domain

Preferred domain: `mokithapiyarathna.com`; alternative: `mokithapiyarathna.co.uk`. Domain availability has **not been conclusively verified** by this project. Check both names in a registrar checkout/search before purchasing. Do not assume availability from search-engine results.

1. Register the domain with a reputable registrar. Compare the renewal price, not just the first-year offer; avoid add-ons you do not need. No domain has been purchased for you.
2. In Cloudflare Pages, open the project **Custom domains** section and add the domain. Follow the dashboard's DNS instructions exactly. If Cloudflare asks you to move DNS to Cloudflare, review the change before confirming; keep any existing email DNS records if you use that domain for email.
3. Choose one canonical version (recommended `https://mokithapiyarathna.com`) and redirect the other hostname (`www` or the alternate apex) to it.
4. In `index.html`, add this inside `<head>` after choosing the final canonical host:
   `<link rel="canonical" href="https://YOUR-FINAL-DOMAIN/">`
5. Update `robots.txt`'s Sitemap URL and the `<loc>` in `sitemap.xml` to the actual final domain. Also update `og:url` if you add it. Commit and redeploy.
6. Wait for the hosting dashboard to show the custom domain as active and HTTPS enabled. Verify the homepage and image URLs on the live domain before sharing it.

## Google Search Console

1. Open Google Search Console and add the final domain as a **Domain property**. Verify it using the DNS TXT record Google provides (this requires access to the domain's DNS).
2. Once the custom domain and HTTPS work, submit `https://YOUR-FINAL-DOMAIN/sitemap.xml` under **Sitemaps**.
3. Use **URL Inspection** for the homepage and select **Request indexing**. Keep the site public and do not block it in robots.txt.
4. Search for the exact name periodically. Indexing and ranking are decided by Google and may take time; neither indexing nor a particular ranking is guaranteed.

## Editing content

- Main text, metadata, structured data and the competition list are in `index.html`.
- Styling and responsive breakpoints are in `styles.css`.
- Menu behavior and the 15-row transparent bout table are in `script.js`.
- Replace or add only athlete-supplied images in `assets/`; update the matching `<img src>` and descriptive `alt` text in `index.html`.
- The medal counts and 15-bout figure are explicitly presented as athlete-reported. Individual results are left as “Not provided”. The weight timeline is labelled approximate, and the site makes no governing-body endorsement claim.

## Image assets

The included WebP images were converted from the six photos supplied in the conversation for faster delivery. They are local site assets, not externally hosted stock images. The hero uses `assets/boxing-5.webp` (the red-kit medal photograph).
